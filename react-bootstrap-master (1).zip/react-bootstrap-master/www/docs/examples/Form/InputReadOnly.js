import Form from 'react-bootstrap/Form';

function InputReadOnlyExample() {
  return (
    <Form.Control type="text" placeholder="Readonly input here..." readOnly />
  );
}

export default InputReadOnlyExample;
