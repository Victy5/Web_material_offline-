import Form from 'react-bootstrap/Form';

function RangeExample() {
  return (
    <>
      <Form.Label>Range</Form.Label>
      <Form.Range />
    </>
  );
}

export default RangeExample;
