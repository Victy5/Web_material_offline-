number of manually triggered releases: 1
